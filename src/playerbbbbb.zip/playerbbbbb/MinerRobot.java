package playerbbbbb;
import battlecode.common.*;

/**
* For static methods that miners will use.
* Each should (most likely) take an rc as input
**/

public class MinerRobot {

  public static void sayHi() {
    System.out.println("I'm a miner robot!");
  }

}
