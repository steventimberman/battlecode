package playerbbbbb;
import battlecode.common.*;

/**
* For static methods that HQ will use.
* Each should (most likely) take an rc as input
**/

public class HQRobot {

  public static void sayHi() {
    System.out.println("I'm an HQ robot!");
  }

}
